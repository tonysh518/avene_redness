<div class="loading-wrap">
    <div class="logo"></div>
    <div class="loading-loader">
        <div class="loading-bar"></div>
    </div>
    <div class="loading-percentage"></div>
</div>
<!--  -->
<div class="header" data-style="margin-top:-100px" data-animate="margin-top:0" data-delay="0" data-time="1000" data-easing="easeInOutQuart">
    <div class="column">
        <a class="logo" href="http://www.eau-thermale-avene.cn/"></a>
        <div class="nav cs-clear">
            <a class="nav1" href="index.php">首页</a>
            <a class="nav2" href="repair.php">解析敏感泛红</a>
            <a class="nav3" href="mask.php">修红舒润面膜</a>
            <a class="nav4" href="scheme.php">修红全方案</a>
            <a class="nav5" href="share.php">达人分享</a>
            <a class="nav6" href="knowledge.php">专家建议</a>
            <span class="navicon dis_mobile"></span>
        </div>
        <a class="navbtn dis_mobile"></a>
    </div>
</div>