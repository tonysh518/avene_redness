$('.nav a').eq(0).bind('click',function(){
    _gaq.push(['anti-redness', 'nav', 'btn1', 'btn1']);
});
$('.nav a').eq(1).bind('click',function(){
    _gaq.push(['anti-redness', 'nav', 'btn2', 'btn2']);
});
$('.nav a').eq(2).bind('click',function(){
    _gaq.push(['anti-redness', 'nav', 'btn3', 'btn3']);
});
$('.nav a').eq(3).bind('click',function(){
    _gaq.push(['anti-redness', 'nav', 'btn4', 'btn4']);
});
$('.nav a').eq(4).bind('click',function(){
    _gaq.push(['anti-redness', 'nav', 'btn5', 'btn5']);
});
$('.nav a').eq(5).bind('click',function(){
    _gaq.push(['anti-redness', 'nav', 'btn6', 'btn6']);
});

$('.intro a').eq(0).bind('click',function(){
    _gaq.push(['anti-redness', 'bottom-nav', 'btn1', 'btn1']);
});
$('.intro a').eq(1).bind('click',function(){
    _gaq.push(['anti-redness', 'bottom-nav', 'btn2', 'btn2']);
});
$('.intro a').eq(2).bind('click',function(){
    _gaq.push(['anti-redness', 'bottom-nav', 'btn3', 'btn3']);
});
$('.intro a').eq(3).bind('click',function(){
    _gaq.push(['anti-redness', 'bottom-nav', 'btn4', 'btn4']);
});

$('.home_video').bind('click',function(){
    _gaq.push(['anti-redness', 'home', 'home_video', 'home_video']);
});

$('.home_siyan').eq(5).bind('click',function(){
    _gaq.push(['anti-redness', 'home', 'siyan', 'siyan']);
});

$('.repair_btn').bind('click',function(){
    _gaq.push(['anti-redness', 'repair', 'smalltest-btn', 'smalltest-btn']);
});

$('.scheme_weibo').bind('click',function(){
    _gaq.push(['anti-redness', 'scheme', 'share-sina', 'share-sina']);
});

$('.kl_weibo').bind('click',function(){
    _gaq.push(['anti-redness', 'knowledge', 'knowledge-weibo', 'knowledge-weibo']);
});

$('.kl_youku').bind('click',function(){
    _gaq.push(['anti-redness', 'knowledge', 'knowledge-youku', 'knowledge-youku']);
});

$('.ft_site').bind('click',function(){
    _gaq.push(['anti-redness', 'footer', 'official-site', 'official-site']);
});

$('.ft_weibo').bind('click',function(){
    _gaq.push(['anti-redness', 'footer', 'avane-weibo', 'avane-weibo']);
});

$('.ft_weibo2').bind('click',function(){
    _gaq.push(['anti-redness', 'footer', 'avane-weibo2', 'avane-weibo2']);
});

$('.ft_app').bind('click',function(){
    _gaq.push(['anti-redness', 'footer', 'avane-app', 'avane-app']);
});
$('#mailinputbtn').bind('click',function(){
    _gaq.push(['anti-redness', 'footer', 'newsletter', 'newsletter']);
});