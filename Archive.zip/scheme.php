<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta name="keywords" content="雅漾修红全方案" />
    <meta name="description" content="雅漾修红全方案页为你提供SOS急救灼热泛红和日常修护2种红血丝修护方案，此外，还介绍了雅漾新品——修红舒润面膜的使用小贴士。" />
    <title>雅漾修红全方案_雅漾AVENE官方网站_为敏感肌肤健康推荐</title>
    <?php
    include('./header.php');
    ?>
</head>
<body id="scheme">
<?php
    include('./nav.php');
?>
<!--  -->
<div class="page" data-style="opacity:0" data-animate="opacity:1" data-delay="1000" data-time="400" data-easing="easeInOutQuart">
    <div class="scheme_hua1"></div>
    <div class="scheme_hua2"></div>
    <div class="scheme_hua3"></div>
    <div class="scheme_imgleft scheme_leftbg" data-style="opacity:0;left:20%;" data-animate="opacity:1;left:50%;" data-delay="2500" data-time="1000" data-easing="easeInOutQuart"></div>
    <div class="scheme_imgleft scheme_ltit" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3200" data-time="1000" data-easing="easeInOutQuart">
        <h3 class="tit"></h3>
    </div>
    <div class="scheme_imgleft scheme_share" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3000" data-time="1000" data-easing="easeInOutQuart"><p class="text"></p></div>
    <a href="http://v.t.sina.com.cn/share/share.php?title=%23%e9%9b%85%e6%bc%be%e8%82%8c%e8%82%a4%e7%81%ad%e7%81%ab%e5%99%a8%23SOS%ef%bc%81%e6%80%a5%e6%95%91%e7%81%bc%e7%83%ad%e6%b3%9b%e7%ba%a2%ef%bc%81%e3%80%90%e6%96%b0%e5%93%81%e4%b8%8a%e5%b8%82%e3%80%91%e9%9b%85%e6%bc%be%e4%bf%ae%e6%8a%a4%e8%88%92%e6%b6%a6%e9%9d%a2%e8%86%9c%ef%bc%8c%e4%bf%ae%e6%8a%a4%e6%95%8f%e6%84%9f%e6%b3%9b%e7%ba%a2%e7%9a%84%e6%9c%89%e6%95%88%e5%88%a9%e5%99%a8%e3%80%82%e6%84%9f%e5%8f%97%e5%81%87%e5%8f%b6%e6%a0%91%e6%a0%b9%e7%a5%9e%e5%a5%87%e4%bf%ae%e7%ba%a2%e5%8a%9b%e9%87%8f%ef%bc%8c%e5%8d%b3%e5%88%bb%e9%99%8d%e4%bd%8e%e7%9a%ae%e8%82%a4%e6%b8%a9%e5%ba%a6%ef%bc%8c%e6%94%b9%e5%96%84%e6%b3%9b%e7%ba%a2%ef%bc%8c%e4%bb%a4%e4%bd%a0%e5%80%8d%e6%84%9f%e6%b0%b4%e6%b6%a6%ef%bc%81%e7%82%b9%e5%87%bbhttp%3a%2f%2ft.cn%2fzRaQ58c%e4%ba%86%e8%a7%a3%e6%9b%b4%e5%a4%9a%e6%96%b0%e5%93%81%e3%80%81%e4%bc%98%e6%83%a0%e5%8f%8a%e6%b4%bb%e5%8a%a8%e4%bf%a1%e6%81%af%e3%80%82&pic=http://www.eau-thermale-avene.cn/anti-redness/img/sina_banner.jpg" target="_blank" class="scheme_imgleft scheme_weibo" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3200" data-time="500" data-easing="easeInOutQuart"></a>
    <a href="javascript:void(0)" class="scheme_imgleft scheme_weixin" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3400" data-time="500" data-easing="easeInOutQuart">
        <div class="qrcode"><img src="./img/qr.png" /></div>
    </a>
    <div class="scheme_imgleft scheme_line" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3200" data-time="500" data-easing="easeInOutQuart"></div>
    <div class="scheme_imgleft scheme_line scheme_line2" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3400" data-time="500" data-easing="easeInOutQuart"></div>
    <div class="scheme_imgleft scheme_line scheme_line3" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3600" data-time="500" data-easing="easeInOutQuart"></div>
    <div class="scheme_imgleft scheme_line scheme_line4" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3800" data-time="500" data-easing="easeInOutQuart"></div>
    <!--  -->
    <p class="dis_mobile arrow_tiem arrow_p"></p>
    <p class="dis_mobile arrow_tiem arrow_n"></p>
    <!--  -->
    <div class="scheme_imgleft scheme_step1" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3200" data-time="500" data-easing="easeInOutQuart">
        <h3 class="tit"></h3><p class="text"></p>
    </div>
    <div class="scheme_imgleft scheme_step2" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3400" data-time="500" data-easing="easeInOutQuart">
        <h3 class="tit"></h3><p class="text"></p>
    </div>
    <div class="scheme_imgleft scheme_step3" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3600" data-time="500" data-easing="easeInOutQuart">
        <h3 class="tit"></h3><p class="text"></p>
    </div>
    <div class="scheme_imgleft scheme_step4" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3800" data-time="500" data-easing="easeInOutQuart">
        <h3 class="tit"></h3><p class="text"></p>
    </div>

    <div class="scheme_step_mobile">
        <ul class="bxslider">
            <li class="scheme_imgleft scheme_mobile_step1" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3000" data-time="500" data-easing="easeInOutQuart">
                <h3 class="tit"></h3><p class="text"></p>
            </li>
            <li class="scheme_imgleft scheme_mobile_step2" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3200" data-time="500" data-easing="easeInOutQuart">
                <h3 class="tit"></h3><p class="text"></p>
            </li>
            <li class="scheme_imgleft scheme_mobile_step3" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3400" data-time="500" data-easing="easeInOutQuart">
                <h3 class="tit"></h3><p class="text"></p>
            </li>
            <li class="scheme_imgleft scheme_mobile_step4" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3600" data-time="500" data-easing="easeInOutQuart">
                <h3 class="tit"></h3><p class="text"></p>
            </li>
        </ul>
    </div>

    <div class="scheme_imgleft scheme_tips" data-style="opacity:0;" data-animate="opacity:1;" data-delay="3800" data-time="1000" data-easing="easeInOutQuart">
        <h3 class="tit"></h3><p class="text"></p>
    </div>
    <!--  -->   
    <div class="fadeEle scheme_imgright scheme_sos" data-style="opacity:0" data-animate="opacity:1" data-delay="1000" data-time="800" data-easing="easeInOutQuart">
        <h3 class="tit">SOS</h3><p class="text"></p>
    </div>
    <div class="fadeEle scheme_imgright scheme_day" data-style="opacity:0;" data-animate="opacity:1;" data-delay="1500" data-time="300" data-easing="linear">
        <h3 class="tit">日常修护</h3><p class="text"></p>
    </div>
    <div class="fadeEle scheme_imgright scheme_jia" data-style="opacity:0;" data-animate="opacity:1;" data-delay="1100" data-time="300" data-easing="linear">
        <h3 class="tit"></h3><p class="text"></p>
    </div>
    <div class="fadeEle scheme_imgright scheme_intro1" data-style="opacity:0;left:40%;" data-animate="opacity:1;left:50%;" data-delay="1100" data-time="300" data-easing="linear">
        <h3 class="tit"></h3><p class="text scheme_introtxt">修红舒润面膜可作为紧急修红的急救面膜使用。在洁面之后均匀涂抹于面部，待皮肤吸收10分钟后,用化妆棉将剩余面膜拭去。配方精简，仅含<span>11种</span>成分。</p>
    </div>
    <div class="fadeEle scheme_imgright scheme_intro2" data-style="opacity:0;left:40%;" data-animate="opacity:1;left:50%;" data-delay="1500" data-time="300" data-easing="linear">
        <h3 class="tit"></h3><p class="text scheme_introtxt">使用面膜之后，喷洒具有舒缓功效的雅漾活泉水，为肌肤补充活性水分子的同时，舒缓肌肤，缓解可能存在的敏感泛红。</p>
    </div>
    <div class="fadeEle scheme_imgright scheme_intro3" data-style="opacity:0;left:60%;" data-animate="opacity:1;left:50%;" data-delay="2200" data-time="300" data-easing="linear">
        <h3 class="tit"></h3><p class="text scheme_introtxt">对于耐受性较差的肌肤来说,洁面的选择也非常关键。应选择质地温和的抗红产品,同时可配合手指肚轻轻按压的手法,以促进血液流动。</p>
    </div>
    <div class="fadeEle scheme_imgright scheme_intro4" data-style="opacity:0;left:60%;" data-animate="opacity:1;left:50%;" data-delay="2700" data-time="300" data-easing="linear">
        <h3 class="tit"></h3><p class="text scheme_introtxt">天然修护保湿因子与雅漾活泉水协同作用，舒缓、保湿，缓解皮肤不适现象。质地润泽，含白凡士林和植物性角鲨烷，有效修复水脂膜，重建皮肤保护屏障。</p>
    </div>
    <div class="fadeEle scheme_imgright scheme_product1" data-style="opacity:0;left:40%;" data-animate="opacity:1;left:50%;" data-delay="1300" data-time="300" data-easing="linear">
        <h3 class="tit"></h3><p class="text"></p>
    </div>
    <div class="fadeEle scheme_imgright scheme_cool" data-style="opacity:0;" data-animate="opacity:1;" data-delay="1400" data-time="300" data-easing="linear">
        <h3 class="tit">即刻清凉</h3><p class="text"></p>
    </div>
    <div class="fadeEle scheme_imgright scheme_product2" data-style="opacity:0;left:40%;" data-animate="opacity:1;left:50%;" data-delay="1500" data-time="300" data-easing="linear">
        <h3 class="tit"></h3><p class="text"></p>
    </div>
    <div class="fadeEle scheme_imgright scheme_product3" data-style="opacity:0;left:60%;" data-animate="opacity:1;left:50%;" data-delay="3000" data-time="300" data-easing="linear">
        <h3 class="tit"></h3><p class="text"></p>
    </div>
    <div class="fadeEle scheme_imgright scheme_product5" data-style="opacity:0;left:60%;" data-animate="opacity:1;left:50%;" data-delay="2500" data-time="300" data-easing="linear">
        <h3 class="tit"></h3><p class="text"></p>
    </div>
    <div class="fadeEle scheme_imgright scheme_product4" data-style="opacity:0;left:60%;" data-animate="opacity:1;left:50%;" data-delay="2600" data-time="300" data-easing="linear">
        <h3 class="tit"></h3><p class="text"></p>
    </div>
    <!--  -->
</div>
<!--  -->
<?php
    include('./footer.php');
?>