<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=640, minimum-scale=0.5, maximum-scale=1.0" />
<link rel="shortcut icon" href="img/avene.ico" type="image/vnd.microsoft.icon" />
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" />
<link href="css/uniform.default.css" rel="stylesheet" type="text/css" />
<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />
<link href="css/jsPane.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script><script type="text/javascript" >_uacct = "UA-20215586-3";urchinTracker();</script><script type="text/javascript">var _gaq = _gaq || [];_gaq.push(['_setAccount', 'UA-20215586-3']);_gaq.push(['_setDomainName', 'eau-thermale-avene.cn']);_gaq.push(['_trackPageview']);(function () {var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);})();</script>
<script type="text/javascript">
    var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
    document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fd3055684f3d977708a830ed251916722' type='text/javascript'%3E%3C/script%3E"));
</script>

<script src="js/jquery-1.8.3.min.js"></script>
<script src="js/modernizr-2.5.3.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/jquery.queryloader22.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/skrollr.min.js"></script>
<script src="js/jquery.form.js"></script>
<script src="js/jquery.uniform.min.js"></script>
<script src="js/jquery.mousewheel.js"></script>
<script src="js/scrollTo.min.js"></script>
<script src="js/jquery.bxslider.js"></script>
<script src="js/jquery.jscrollpane.js"></script>
<script src="js/jquery.validate.js"></script>
<script src="js/waypoint.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/app.js"></script>
<script src="js/tracking.js"></script>
<!--  -->
<!--IE6透明判断-->
<!--[if IE 6]>
<script src="js/DD_belatedPNG.js"></script>
<script>
    DD_belatedPNG.fix('*');
    document.execCommand("BackgroundImageCache", false, true);
</script>
<![endif]-->
<!--  -->