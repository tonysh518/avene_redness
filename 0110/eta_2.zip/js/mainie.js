!!(function(){

        $(".section1_bg").backstretch("img/section1_bg.jpg");
        $(".section2_bg").backstretch("img/section2_bg.jpg");
        $(".section2_bg2").backstretch("img/section2_bg2.jpg");
        $(".section2_cloud").backstretch("img/section2_cloud.png");
        $(".section3_bg").backstretch("img/section3_bg.jpg");
        $(".section4_bg").backstretch("img/section4_bg.jpg");
        $(".section4_cloud").backstretch("img/section4_cloud.png");
        $(".section5_bg").backstretch("img/section5_bg.jpg");
        $(".section6_bg").backstretch("img/section6_bg.jpg");
        $(".section7_bg").backstretch("img/section7_bg.jpg");
        $(".section7_rain").backstretch("img/section7_rain.png");
        $(".section7_water").backstretch("img/section7_water.png");
        $(".section8_bg").backstretch("img/section8_bg.jpg");
        $(".section9_bg").backstretch("img/section9_bg1.jpg");
        $(".section10_bg").backstretch("img/section10_bg.jpg");
        $(".section10_bg2").backstretch("img/section10_bg2.jpg");


})();

