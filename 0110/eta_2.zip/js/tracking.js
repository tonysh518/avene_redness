$('.nav0').bind('click',function(){
    ga('send', 'eta', 'nav', 'btn1', 'btn1');
});
$('.nav1').bind('click',function(){
    ga('send', 'eta', 'nav', 'btn2', 'btn2');
});
$('.nav2').bind('click',function(){
    ga('send', 'eta', 'nav', 'btn3', 'btn3');
});
$('.nav3').bind('click',function(){
    ga('send', 'eta', 'nav', 'btn4', 'btn4');
});
$('.nav4').bind('click',function(){
    ga('send', 'eta', 'nav', 'btn5', 'btn5');
});
$('.nav5').bind('click',function(){
    ga('send', 'eta', 'nav', 'btn6', 'btn6');
});

$('.section1_ball1').bind('click',function(){
    ga('send', 'eta', 'home', 'round_btn1', 'round_btn1');
});
$('.section1_ball2').bind('click',function(){
    ga('send', 'eta', 'home', 'round_btn2', 'round_btn2');
});
$('.section1_ball3').bind('click',function(){
    ga('send', 'eta', 'home', 'round_btn4', 'round_btn4');
});
$('.section1_ball4').bind('click',function(){
    ga('send', 'eta', 'home', 'round_btn5', 'round_btn5');
});
$('.section1_ball5_btn').bind('click',function(){
    ga('send', 'eta', 'home', 'round_btn3', 'round_btn3');
});